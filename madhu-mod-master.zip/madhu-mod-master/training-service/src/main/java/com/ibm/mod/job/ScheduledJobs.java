package com.ibm.mod.job;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.ibm.mod.entity.Training;
import com.ibm.mod.service.TrainingsService;
import com.ibm.mod.model.Constants;
import com.ibm.mod.model.Constants.TrainingStatus;

@Component
public class ScheduledJobs {

	private static Logger logger = LoggerFactory.getLogger(ScheduledJobs.class);

	@Autowired
	private TrainingsService trainingService;

	@Scheduled(cron = "${notcompleted.job.cron}")
	public synchronized void trainingToNotCompletedJob() {

		List<String> trainingStatus = new ArrayList<String>();
		trainingStatus.add(TrainingStatus.NOT_COMPLETED.getStatus());
		trainingStatus.add(TrainingStatus.COMPLETED.getStatus());
		trainingStatus.add(TrainingStatus.REJECTED.getStatus());

		List<Training> trainingList = trainingService.findExpiredTrainings(trainingStatus);
		logger.info("Number of records found " + trainingList.size());
		//for (Training t : trainingList) {
			// trainingService.updateTrainingToNotCompleted(t.getId());
		//}
	}

	@Scheduled(cron = "${training_progress.job.cron}")
	public synchronized void updateTrainingProgressJob() {

		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");
		List<String> trainingStatus = Constants.getInProgress();
		List<Training> trainingList = trainingService.findByTrainingStatus(trainingStatus);
		logger.info("Number of records found " + trainingList.size());

		for (Training t : trainingList) {
			int days, hours, extraHours = 0;
			float progress = 0.0f;

			try {
				days = (int) (df.parse(t.getEndDate()).getTime() - df.parse(t.getStartDate()).getTime()) / 1000 / 60 / 60 / 24;
				hours = (int) (tf.parse(t.getEndTime()).getTime() - tf.parse(t.getStartTime()).getTime()) / 1000 / 60 / 60;
				int totalTrainingHours = (days + 1) * hours;

				Calendar cal = Calendar.getInstance();
				String curDateStr = df.format(cal.getTime());
				String curTimeStr = tf.format(cal.getTime());
				days = (int) (df.parse(curDateStr).getTime() - df.parse(t.getStartDate()).getTime()) / 1000 / 60 / 60 / 24;
				if (tf.parse(curTimeStr).getTime() > tf.parse(t.getEndTime()).getTime())
					extraHours = hours;
				else
					extraHours = (int) (tf.parse(curTimeStr).getTime() - tf.parse(t.getStartTime()).getTime()) / 1000 / 60 / 60;
				int totalTrainingHoursSpent = (days * hours) + extraHours;

				progress = (totalTrainingHoursSpent * 100) / totalTrainingHours;
				if (t.getProgress().floatValue() != progress && (progress == 25.0 || progress == 50.0 || progress == 75.0 || progress == 100.0))
					trainingService.updateTrainingProgress(t.getId(), (int)progress);
			} catch (ParseException e) {
				e.printStackTrace();
			}

		}
	}

}
