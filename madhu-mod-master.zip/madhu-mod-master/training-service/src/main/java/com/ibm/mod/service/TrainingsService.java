package com.ibm.mod.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.ibm.mod.entity.Training;
import com.ibm.mod.exception.DataValidationException;
import com.ibm.mod.exception.ResourceExistException;
import com.ibm.mod.exception.ResourceNotFoundException;
import com.ibm.mod.exception.ServiceUnavailableException;
import com.ibm.mod.model.Constants;
import com.ibm.mod.model.Constants.TrainingStatus;
import com.ibm.mod.model.MentorSkillsDtls;
import com.ibm.mod.model.PaymentCommDtls;
import com.ibm.mod.model.PaymentDtls;
import com.ibm.mod.model.SkillDtls;
import com.ibm.mod.model.TrainingDtls;
import com.ibm.mod.model.UserDtls;
import com.ibm.mod.proxy.PaymentServiceProxy;
import com.ibm.mod.proxy.SearchServiceProxy;
import com.ibm.mod.proxy.SkillServiceProxy;
import com.ibm.mod.proxy.UserServiceProxy;
import com.ibm.mod.reprository.TrainingRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
@Transactional(readOnly = true)
public class TrainingsService {

	@Autowired
	private TrainingRepository trainingRepository;

	@Autowired
	private UserServiceProxy userProxy;

	@Autowired
	private SearchServiceProxy searchProxy;

	@Autowired
	private SkillServiceProxy skillProxy;

	@Autowired
	private PaymentServiceProxy paymentProxy;

	@Autowired
	private EmailService emailService;

	@SuppressWarnings("deprecation")
	@HystrixCommand(fallbackMethod = "fallback_findAllTrainings", commandKey = "findAllTrainings", groupKey = "findAllTrainings")
	public Page<TrainingDtls> findAllTrainings(String orderBy, String direction, int page, int size) {

		List<TrainingDtls> trainingDtlsList = new ArrayList<>();
		TrainingDtls trainingDtlObj = null;
		UserDtls user = null, mentor = null;
		SkillDtls skill = null;
		Sort sort = null;
		if (direction.equals("ASC")) {
			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
		} else if (direction.equals("DESC")) {
			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
		}
		Pageable pageable = new PageRequest(page, size, sort);

		List<Training> trainingList = trainingRepository.findAll(pageable).getContent();
		for (Training trainingObj : trainingList) {
			user = userProxy.findById(trainingObj.getUserId());
			mentor = userProxy.findById(trainingObj.getMentorId());
			skill = skillProxy.findById(trainingObj.getSkillId());
			if (user != null && mentor != null && skill != null) {
				trainingDtlObj = new TrainingDtls();
				BeanUtils.copyProperties(trainingObj, trainingDtlObj);
				trainingDtlObj.setUserName(user.getFirstName() + " " + user.getLastName());
				trainingDtlObj.setMentorName(mentor.getFirstName() + " " + mentor.getLastName());
				trainingDtlObj.setSkillName(skill.getName());
				trainingDtlsList.add(trainingDtlObj);
			}
		}
		return new PageImpl<>(trainingDtlsList, pageable, trainingDtlsList.size());
	}

	@SuppressWarnings("deprecation")
	@HystrixCommand(fallbackMethod = "fallback_findProposedTrainings", commandKey = "findProposedTrainings", groupKey = "findProposedTrainings")
	public Page<TrainingDtls> findProposedTrainings(Long mentorId, String orderBy, String direction, int page,
			int size) {

		List<TrainingDtls> trainingDtlsList = new ArrayList<>();
		TrainingDtls trainingDtlObj = null;
		UserDtls user = null;
		SkillDtls skill = null;
		Sort sort = null;
		if (direction.equals("ASC")) {
			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
		} else if (direction.equals("DESC")) {
			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
		}
		Pageable pageable = new PageRequest(page, size, sort);
		List<Training> trainingList = trainingRepository.findProposedTrainings(mentorId, pageable).getContent();
		
		for (Training trainingObj : trainingList) {
			user = userProxy.findById(trainingObj.getUserId());
			skill = skillProxy.findById(trainingObj.getSkillId());
			if (user != null && skill != null) {
				trainingDtlObj = new TrainingDtls();
				BeanUtils.copyProperties(trainingObj, trainingDtlObj);
				trainingDtlObj.setUserName(user.getFirstName() + " " + user.getLastName());
				trainingDtlObj.setSkillName(skill.getName());
				trainingDtlsList.add(trainingDtlObj);
			}
		}
		return new PageImpl<>(trainingDtlsList, pageable, trainingDtlsList.size());
	}

	@SuppressWarnings("deprecation")
	@HystrixCommand(fallbackMethod = "fallback_findByMentorIdSkillId", commandKey = "findByMentorIdSkillId", groupKey = "findByMentorIdSkillId")
	public Page<TrainingDtls> findByMentorIdSkillId(Long mentorId, Long skillId, String orderBy, String direction, int page,
			int size) {

		List<TrainingDtls> trainingDtlsList = new ArrayList<>();
		TrainingDtls trainingDtlObj = null;
		UserDtls user = null;
		SkillDtls skill = null;
		Sort sort = null;
		if (direction.equals("ASC")) {
			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
		} else if (direction.equals("DESC")) {
			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
		}
		Pageable pageable = new PageRequest(page, size, sort);

		List<Training> trainingList = trainingRepository.findByMentorIdSkillId(mentorId, skillId, pageable).getContent();
		for (Training trainingObj : trainingList) {
			user = userProxy.findById(trainingObj.getUserId());
			skill = skillProxy.findById(trainingObj.getSkillId());
			if (user != null && skill != null) {
				trainingDtlObj = new TrainingDtls();
				BeanUtils.copyProperties(trainingObj, trainingDtlObj);
				trainingDtlObj.setUserName(user.getFirstName() + " " + user.getLastName());
				trainingDtlObj.setSkillName(skill.getName());
				trainingDtlsList.add(trainingDtlObj);
			}
		}
		return new PageImpl<>(trainingDtlsList, pageable, trainingDtlsList.size());
	}

	@SuppressWarnings("deprecation")
	@HystrixCommand(fallbackMethod = "fallback_findByUserIdAndStatus", commandKey = "findByUserIdAndStatus", groupKey = "findByUserIdAndStatus")
	public Page<TrainingDtls> findByUserIdAndStatus(Long userId, List<String> trainingStatus, String orderBy,
			String direction, int page, int size) {

		List<TrainingDtls> trainingDtlsList = new ArrayList<>();
		TrainingDtls trainingDtlObj = null;
		UserDtls mentor = null;
		SkillDtls skill = null;
		Sort sort = null;
		if (direction.equals("ASC")) {
			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
		} else if (direction.equals("DESC")) {
			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
		}
		Pageable pageable = new PageRequest(page, size, sort);

		List<Training> trainingList = trainingRepository.findByUserIdAndStatus(userId, trainingStatus, pageable).getContent();
		for (Training trainingObj : trainingList) {
			mentor = userProxy.findById(trainingObj.getMentorId());
			skill = skillProxy.findById(trainingObj.getSkillId());
			if (mentor != null && skill != null) {
				trainingDtlObj = new TrainingDtls();
				BeanUtils.copyProperties(trainingObj, trainingDtlObj);
				trainingDtlObj.setMentorName(mentor.getFirstName() + " " + mentor.getLastName());
				trainingDtlObj.setSkillName(skill.getName());
				trainingDtlsList.add(trainingDtlObj);
			}
		}

		return new PageImpl<>(trainingDtlsList, pageable, trainingDtlsList.size());
	}

	@SuppressWarnings("deprecation")
	@HystrixCommand(fallbackMethod = "fallback_findByMentorIdAndStatus", commandKey = "findByMentorIdAndStatus", groupKey = "findByMentorIdAndStatus")
	public Page<TrainingDtls> findByMentorIdAndStatus(Long mentorId, List<String> trainingStatus, String orderBy,
			String direction, int page, int size) {

		List<TrainingDtls> trainingDtlsList = new ArrayList<>();
		TrainingDtls trainingDtlObj = null;
		UserDtls user = null;
		SkillDtls skill = null;
		Sort sort = null;
		if (direction.equals("ASC")) {
			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
		} else if (direction.equals("DESC")) {
			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
		}
		Pageable pageable = new PageRequest(page, size, sort);

		List<Training> trainingList = trainingRepository.findByMentorIdAndStatus(mentorId, trainingStatus, pageable).getContent();
		for (Training trainingObj : trainingList) {
			user = userProxy.findById(trainingObj.getUserId());
			skill = skillProxy.findById(trainingObj.getSkillId());
			if (user != null && skill != null) {
				trainingDtlObj = new TrainingDtls();
				BeanUtils.copyProperties(trainingObj, trainingDtlObj);
				trainingDtlObj.setUserName(user.getFirstName() + " " + user.getLastName());
				trainingDtlObj.setSkillName(skill.getName());
				trainingDtlsList.add(trainingDtlObj);
			}
		}

		return new PageImpl<>(trainingDtlsList, pageable, trainingDtlsList.size());
	}
	
	@HystrixCommand(fallbackMethod = "fallback_findAvgRating", commandKey = "findAvgRating", groupKey = "findAvgRating")
	public List<TrainingDtls> findAvgRating(Long mentorId, Long skillId) {
		
		List<TrainingDtls> trainingDtlsList = new ArrayList<>();
		TrainingDtls trainingDtlObj = null;
		UserDtls user = null;
		SkillDtls skill = null;
		
		List<Training> trainingList= trainingRepository.findAvgRating(mentorId,skillId);
		for (Training trainingObj : trainingList) {
			user = userProxy.findById(trainingObj.getUserId());
			skill = skillProxy.findById(trainingObj.getSkillId());
			if (user != null && skill != null) {
				trainingDtlObj = new TrainingDtls();
				BeanUtils.copyProperties(trainingObj, trainingDtlObj);
				trainingDtlObj.setUserName(user.getFirstName() + " " + user.getLastName());
				trainingDtlObj.setSkillName(skill.getName());
				trainingDtlsList.add(trainingDtlObj);
			}
		}
		return trainingDtlsList;
	}
	
	
	@HystrixCommand(fallbackMethod = "fallback_findAvgRating1", commandKey = "findAvgRating1", groupKey = "findAvgRating1")
	public List<TrainingDtls> findAvgRating1(List<TrainingDtls> list) {
		
		List<TrainingDtls> trainingDtlsList = new ArrayList<>();
		TrainingDtls trainingDtlObj = null;
		UserDtls user = null;
		SkillDtls skill = null;
		for (TrainingDtls trainingDtls : list){
			Float avgRating =trainingRepository.findAvgRating1(trainingDtls.getMentorId(),trainingDtls.getSkillId()); 
			System.out.println("Average Rating Received from Repository--->"+avgRating);
			trainingDtls.setAvgRating(avgRating);
			BeanUtils.copyProperties(trainingDtls, trainingDtlObj);
			trainingDtlsList.add(trainingDtlObj);
		}

		return trainingDtlsList;
	}
	
	
	@HystrixCommand(fallbackMethod = "fallback_findById", commandKey = "findById", groupKey = "findById", ignoreExceptions = {
			ResourceNotFoundException.class })
	public Training findById(Long id) {
		return Optional.ofNullable(trainingRepository.findById(id).get())
				.orElseThrow(() -> new ResourceNotFoundException("Training Id " + id + " not found"));
	}

	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_proposeTraining", commandKey = "proposeTraining", groupKey = "proposeTraining", ignoreExceptions = {
			ResourceNotFoundException.class, ResourceExistException.class })
	public Training proposeTraining(Training training) {

		UserDtls user = userProxy.findById(training.getUserId());
		UserDtls mentor = userProxy.findById(training.getMentorId());
		SkillDtls skill = skillProxy.findById(training.getSkillId());

		if (user == null)
			throw new ResourceNotFoundException("User Id  " + training.getUserId() + " not found");
		else if (mentor == null)
			throw new ResourceNotFoundException("Mentor Id  " + training.getMentorId() + " not found");
		else if (skill == null)
			throw new ResourceNotFoundException("Skill Id  " + training.getSkillId() + " not found");
		else {
			Training OldTraining = trainingRepository.findRegisteredTraining(training.getUserId(), training.getMentorId(), training.getSkillId(),
					training.getStartDate(), training.getEndDate(), training.getStartTime(), training.getEndTime());
			if (OldTraining != null)
				throw new ResourceExistException("Training proposal on " + skill.getName()
						+ " from " + training.getStartDate() + " to " + training.getEndDate()
						+ " and " + training.getStartTime() + " - " + training.getEndTime() +" already sent to mentor");

			
			trainingRepository.save(training);

			String subject = "Request for training on " + skill.getName();
			String text = "Hi " + mentor.getFirstName() + ",<br><br>I want to take training on " + skill.getName()
					+ " from " + training.getStartDate() + " to " + training.getEndDate() + " for time slot "
					+ training.getStartTime() + " - " + training.getEndTime();
			emailService.sendMail(user.getUserName(), mentor.getUserName(), subject, text);

			return training;
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_updateTraining", commandKey = "updateTraining", groupKey = "updateTraining", ignoreExceptions = {
			ResourceNotFoundException.class, DataValidationException.class })
	public Training updateTraining(Long id, Training training, String authToken) {

		Training oldTraining = trainingRepository.findById(id).get();
		if (oldTraining == null)
			throw new ResourceNotFoundException("Training Id " + id + " not found");

		UserDtls user = userProxy.findById(oldTraining.getUserId());
		UserDtls mentor = userProxy.findById(oldTraining.getMentorId());
		SkillDtls skill = skillProxy.findById(oldTraining.getSkillId());

		boolean updateFlag = false;
        boolean mailFlag = false;
        
		// sent mail notification to ACCEPT/REJECT proposal by mentor
		if (oldTraining.getStatus().equals(TrainingStatus.PROPOSED.getStatus())
				&& (training.getStatus().equals(TrainingStatus.CONFIRMED.getStatus())
						|| training.getStatus().equals(TrainingStatus.REJECTED.getStatus()))) {
			mailFlag = true;

			if (training.getStatus().equals(TrainingStatus.CONFIRMED.getStatus())
					|| training.getStatus().equals(TrainingStatus.REJECTED.getStatus())) {
				oldTraining.setStatus(training.getStatus());
				updateFlag = true;
			}
			if (training.getStatus().equals(TrainingStatus.CONFIRMED.getStatus())) {
				searchProxy.addCalendarEntry(authToken, oldTraining.getMentorId(), oldTraining.getSkillId(),
						oldTraining.getStartDate(), oldTraining.getEndDate(), oldTraining.getStartTime(),
						oldTraining.getEndTime());
				searchProxy.updateMentorTrainingCount(authToken, oldTraining.getMentorId(), oldTraining.getSkillId());
			}
		} else if (training.getAmountReceived() != 0.0f) { // training amount validation
			if (!oldTraining.getStatus().equals(TrainingStatus.CONFIRMED.getStatus()))
				throw new DataValidationException(
						"To pay amount for training, training status should be " + TrainingStatus.TRAINING_STARTED.getStatus());
			MentorSkillsDtls mentorSkillDtlsObj = searchProxy.findByMentorIdSkillId(oldTraining.getMentorId(), oldTraining.getSkillId());
			
			List<Training> trainingList=trainingRepository.findTraining(oldTraining.getMentorId(), oldTraining.getSkillId());
			float totalRating = 0.0f;
			float avgRating=0.0f;
			for(Training tr: trainingList){
				totalRating=totalRating+tr.getRating();
			}
			int size=trainingList.size();
			avgRating=totalRating/size;
//			List<Training> trainingList = trainingRepository.findAvgRating(oldTraining.getMentorId(), oldTraining.getSkillId());
//			TrainingDtls trainingDtlsObj=null;
//			Training trainingObj1 = trainingList.get(0); 
//			user = userProxy.findById(trainingObj1.getUserId());
//			skill = skillProxy.findById(trainingObj1.getSkillId());
//			if (user != null && skill != null) {
//				trainingDtlsObj = new TrainingDtls();
//				BeanUtils.copyProperties(trainingObj1, trainingDtlsObj);
//				trainingDtlsObj.setUserName(user.getFirstName() + " " + user.getLastName());
//				trainingDtlsObj.setSkillName(skill.getName());
//			}
			
//			if(trainingDtlsObj != null)
//				avgRating = trainingDtlsObj.getAvgRating();
			//Basic Fee + Basic Fee * (0.15 + avg rating/5)
			PaymentCommDtls paymtComm = paymentProxy.findPaymentCommission(new Long(1));
			//float commission = mentorSkillDtls.getFees() * ((float) paymtComm.getCommissionPercent() / 100);
			//float totalFees = mentorSkillDtls.getFees() + commission;
			float totalFees = mentorSkillDtlsObj.getFees() + mentorSkillDtlsObj.getFees()
					* ((mentorSkillDtlsObj.getYearsOfExperience() / 100) + avgRating / 5);
			float commission = totalFees * ((float) paymtComm.getCommissionPercent() / 100);
			if (!training.getAmountReceived().equals(totalFees))
				throw new DataValidationException("Amount should be equal to training fees " + totalFees);
			oldTraining.setAmountReceived(training.getAmountReceived());
			oldTraining.setCommissionAmount(commission);
			updateFlag = true;
		} else if (training.getRating() != 0.0f) {
			if (!Constants.getInProgress().contains(oldTraining.getStatus()))
				throw new DataValidationException("To give rating, training status should be among " + Constants.getInProgress().toString());
			oldTraining.setRating(training.getRating());
			updateFlag = true;
		} else if (training.getStatus() != null && Constants.getInProgress().contains(training.getStatus())) {
			oldTraining.setStatus(training.getStatus());
			updateFlag = true;
		}

		if (updateFlag) {
			trainingRepository.save(oldTraining);
			if(mailFlag) {
				String subject = "Request for training on " + skill.getName();
				String text = "Hi " + user.getFirstName() + ",<br><br>Your proposal request for training " + skill.getName()
						+ " from " + oldTraining.getStartDate() + " to " + oldTraining.getEndDate() + " for time slot "
						+ oldTraining.getStartTime() + " - " + oldTraining.getEndTime() + " is " + training.getStatus();
				emailService.sendMail(mentor.getUserName(), user.getUserName(), subject, text);
			}
		}

		return oldTraining;

	}

	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_deleteTraining", commandKey = "deleteTraining", groupKey = "deleteTraining", ignoreExceptions = {
			ResourceNotFoundException.class })
	public void deleteTraining(Long id) {

		trainingRepository.findById(id).map(training -> {
			trainingRepository.delete(training);
			return true;
		}).orElseThrow(() -> new ResourceNotFoundException("Training Id " + id + " not found"));
	}

	@HystrixCommand(fallbackMethod = "fallback_findExpiredTrainings", commandKey = "findExpiredTrainings", groupKey = "findExpiredTrainings")
	public List<Training> findExpiredTrainings(List<String> trainingStatus) {
		return trainingRepository.findExpiredTrainings(trainingStatus);
	}

	@HystrixCommand(fallbackMethod = "fallback_findByTrainingStatus", commandKey = "findByTrainingStatus", groupKey = "findByTrainingStatus")
	public List<Training> findByTrainingStatus(List<String> trainingStatus) {
		
		return trainingRepository.findByTrainingStatus(trainingStatus);
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_updateTrainingToNotCompleted", commandKey = "updateTrainingToNotCompleted", groupKey = "updateTrainingToNotCompleted", ignoreExceptions = {
			ResourceNotFoundException.class })
	public void updateTrainingToNotCompleted(Long id) {

		trainingRepository.findById(id).map(training -> {
			training.setStatus(TrainingStatus.NOT_COMPLETED.getStatus());
			trainingRepository.save(training);
			return true;
		}).orElseThrow(() -> new ResourceNotFoundException("Training Id " + id + " not found"));
	}

	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_updateTrainingProgress", commandKey = "updateTrainingProgress", groupKey = "updateTrainingProgress")
	public void updateTrainingProgress(Long id, int progress) {

		Training training = trainingRepository.findById(id).get();
		if(training == null)
			return;
		
		training.setProgress(progress);
		if (training.getProgress().equals(100))
			training.setStatus(TrainingStatus.COMPLETED.getStatus());

		// add payment information
		PaymentDtls payment = new PaymentDtls();
		Float amountToMentor = ((training.getAmountReceived() - training.getCommissionAmount())
				* ((float) training.getProgress() / 100))
				- paymentProxy.findTotalPaidAmountByMentorId(training.getMentorId(), id).getTotalAmountToMentor();
		payment.setAmount(amountToMentor);
		payment.setRemarks("Amount " + amountToMentor + " paid to mentor");
		payment.setTxnType("CR");
		paymentProxy.addPayment(training.getMentorId(), id, payment);

		trainingRepository.save(training);
	}

	
	// list of fallback method for @HystrixCommand
	public Page<TrainingDtls> fallback_findAllTrainings(String orderBy, String direction, int page, int size) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Page<TrainingDtls> fallback_findProposedTrainings(Long mentorId, String orderBy, String direction, int page,
			int size) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Page<TrainingDtls> fallback_findByMentorIdSkillId(Long mentorId, Long skillId, String orderBy,
			String direction, int page, int size) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Page<TrainingDtls> fallback_findByUserIdAndStatus(Long userId, List<String> trainingStatus, String orderBy,
			String direction, int page, int size) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Page<TrainingDtls> fallback_findByMentorIdAndStatus(Long mentorId, List<String> trainingStatus,
			String orderBy, String direction, int page, int size) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public List<TrainingDtls> fallback_findAvgRating(List<TrainingDtls> list) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public List<TrainingDtls> fallback_findAvgRating1(List<TrainingDtls> list) {
		throw new ServiceUnavailableException("Service Unavailable");
	}
	public Training fallback_findById(Long id) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Training fallback_proposeTraining(Training training) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Training fallback_updateTraining(Long id, Training training, String authToken) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public void fallback_deleteTraining(Long id) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public List<Training> fallback_findExpiredTrainings(List<String> trainingStatus) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public List<Training> fallback_findByTrainingStatus(List<String> trainingStatus) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public void fallback_updateTrainingToNotCompleted(Long id) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public void fallback_updateTrainingProgress(Long id, int progress) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

}
