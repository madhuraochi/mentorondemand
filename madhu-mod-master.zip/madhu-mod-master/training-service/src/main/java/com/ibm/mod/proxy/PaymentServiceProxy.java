package com.ibm.mod.proxy;

import org.springframework.cloud.openfeign.FeignClient;

import javax.validation.Valid;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.ibm.mod.model.ApiResponse;
import com.ibm.mod.model.PaymentCommDtls;
import com.ibm.mod.model.PaymentDtls;

@FeignClient(name = "payment-service")
@RibbonClient(name = "payment-service")
public interface PaymentServiceProxy {

	@GetMapping("/payments/findTotalPaidAmountByMentorId/{mentorId}")
	public PaymentDtls findTotalPaidAmountByMentorId(
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "trainingId", required = true) Long trainingId);

	@PostMapping("/payments/addPayment/{mentorId}/{trainingId}")
	public ApiResponse<?> addPayment(
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "trainingId", required = true) Long trainingId, 
			@Valid @RequestBody PaymentDtls payment);
	
	@GetMapping("payments/findPaymentCommission/{id}")
	public PaymentCommDtls findPaymentCommission(
			@PathVariable(value = "id", required = true) Long id);

}