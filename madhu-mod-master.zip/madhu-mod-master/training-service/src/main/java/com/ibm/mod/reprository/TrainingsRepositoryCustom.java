//package com.ibm.mod.reprository;
//
//import java.util.List;
//import com.ibm.mod.model.TrainingDtls;
//
//public interface TrainingsRepositoryCustom {
//
//	List<TrainingDtls> findAvgRating(List<TrainingDtls> list);
//	
//	TrainingDtls findAvgRating(Long mentorId, Long skillId);
//
//}
