package com.ibm.mod.model;

import java.util.ArrayList;

public class Constants {

	public static final long ACCESS_TOKEN_VALIDITY_SECONDS = 5 * 60 * 60;
	public static final String SIGNING_KEY = "devglan123r";
	public static final String TOKEN_PREFIX = "Bearer ";
	public static final String HEADER_STRING = "Authorization";
	public static final String AUTHORITIES_KEY = "scopes";

	public enum UserRole {

		ROLE_ADMIN("ADMIN"), ROLE_MENTOR("MENTOR"), ROLE_USER("USER");
		private final String role;

		private UserRole(String role) {
			this.role = role;
		}

		public String getRole() {
			return role;
		}
	}

	public enum ProposoalStuts {

		ACCEPT("ACCEPT"), REJECT("REJECT");
		private final String status;

		private ProposoalStuts(String status) {
			this.status = status;
		}

		public String getStatus() {
			return status;
		}
	}

	private static ArrayList<Integer> trainingProgress = new ArrayList<Integer>(5);

	public static ArrayList<Integer> getTrainingProgress() {
		Constants.trainingProgress.add(25);
		Constants.trainingProgress.add(50);
		Constants.trainingProgress.add(75);
		Constants.trainingProgress.add(100);
		return trainingProgress;
	}

	private static ArrayList<String> inProgress = new ArrayList<String>(5);

	public static ArrayList<String> getInProgress() {
		Constants.inProgress.add(TrainingStatus.PROPOSED.getStatus());
		Constants.inProgress.add(TrainingStatus.CONFIRMED.getStatus());
		Constants.inProgress.add(TrainingStatus.TRAINING_STARTED.getStatus());
		Constants.inProgress.add(TrainingStatus.NOT_COMPLETED.getStatus());
		return inProgress;
	}

	public enum TrainingStatus {

		INPROGRESS("INPROGRESS"), PROPOSED("PROPOSED"), CONFIRMED("CONFIRMED"), TRAINING_STARTED(
				"TRAINING-STARTED"), NOT_COMPLETED("NOT-COMPLETED"), COMPLETED("COMPLETED"), REJECTED("REJECTED");
		private final String status;

		private TrainingStatus(String status) {
			this.status = status;
		}

		public String getStatus() {
			return status;
		}
	}

	public static void main(String[] args) {
		System.out.println(getInProgress());
		String status = "";
		for (String str : Constants.getInProgress())
			status += "'" + str + "',";
		status = status.substring(0, status.lastIndexOf(","));
		System.out.println(status);
	}
}
