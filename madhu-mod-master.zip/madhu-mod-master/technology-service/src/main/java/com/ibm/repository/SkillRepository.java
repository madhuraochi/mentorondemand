package com.ibm.repository;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import com.ibm.entity.Skill;


public interface SkillRepository extends PagingAndSortingRepository<Skill, Long> {
//	public interface SkillRepository extends JpaRepository<Skill, Long> {
	
	@Query(value = "SELECT s FROM Skill s")
	Page<Skill> findAll(Pageable pageable);
	
	@Query(value = "SELECT s FROM Skill s WHERE LOWER(name)=?1")
	public Skill findByName(String skillName);
	
	@Query(value = "SELECT s FROM Skill s WHERE LOWER(name) like ?1%")
	public List<Skill> findByLikeName(String name);
}
