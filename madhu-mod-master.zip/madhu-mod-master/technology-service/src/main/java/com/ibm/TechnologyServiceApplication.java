package com.ibm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.ibm.entity.Skill;
import com.ibm.repository.SkillRepository;


@EnableHystrixDashboard
@EnableCircuitBreaker
@EnableEurekaClient
@SpringBootApplication
@EnableJpaAuditing
@EnableJpaRepositories
public class TechnologyServiceApplication implements CommandLineRunner{
//public class TechnologyServiceApplication{

	@Autowired
	private SkillRepository skillRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(TechnologyServiceApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		
		if (skillRepository.findByName("JAVA") == null) {
	     Skill skill = new Skill("JAVA","OOPS,Constructors","None");
	     skillRepository.save(skill);
		}
	}

}

