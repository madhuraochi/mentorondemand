package com.ibm.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "skill")
public class Skill extends AuditModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "name", nullable = false)
	private String name;

	@Column(name = "toc", nullable = false)
	private String toc;

	@Column(name = "prerequisites", nullable = false)
	private String prerequisites;
	
	public Skill() {
		super();
	}
	
	public Skill(String name, String toc, String prerequisites){
		super();
		this.name=name;
		this.toc=toc;
		this.prerequisites = prerequisites;
	};

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getToc() {
		return toc;
	}

	public void setToc(String toc) {
		this.toc = toc;
	}

//	public Float getCost() {
//		return cost;
//	}
//
//	public void setCost(Float cost) {
//		this.cost = cost;
//	}
//
//	public Float getCommissionPercentage() {
//		return commissionPercentage;
//	}
//
//	public void setCommissionPercentage(Float commissionPercentage) {
//		this.commissionPercentage = commissionPercentage;
//	}
//
//	public String getCurrency() {
//		return currency;
//	}
//
//	public void setCurrency(String currency) {
//		this.currency = currency;
//	}

	public String getPrerequisites() {
		return prerequisites;
	}

	public void setPrerequisites(String prerequisites) {
		this.prerequisites = prerequisites;
	}

//	public MentorSkills getMentorSkills() {
//		return mentorSkills;
//	}
//
//	public void setMentorSkills(MentorSkills mentorSkills) {
//		this.mentorSkills = mentorSkills;
//	}
//
//	public Set<Trainings> getTarinings() {
//		return tarinings;
//	}
//
//	public void setTarinings(Set<Trainings> tarinings) {
//		this.tarinings = tarinings;
//	}

}
