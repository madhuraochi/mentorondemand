package com.ibm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.entity.Skill;
import com.ibm.exception.ResourceExistException;
import com.ibm.exception.ResourceNotFoundException;
import com.ibm.exception.ServiceUnavailableException;
import com.ibm.repository.SkillRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
@Transactional(readOnly = true)
public class SkillService {

	@Autowired
	private SkillRepository skillRepository;

	@SuppressWarnings("deprecation")
	@HystrixCommand(fallbackMethod = "fallback_findAllSkills", commandKey = "findAllSkills", groupKey = "findAllSkills")
	public Page<Skill> findAllSkills(String orderBy, String direction, int page, int size) {

		Sort sort = null;
		if (direction.equals("ASC")) {
			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
		} else if (direction.equals("DESC")) {
			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
		}
		Pageable pageable = new PageRequest(page, size, sort);
		return skillRepository.findAll(pageable);
	}

	@HystrixCommand(fallbackMethod = "fallback_findById", commandKey = "findById", groupKey = "findById", ignoreExceptions = {
			ResourceNotFoundException.class })
	public Skill findById(Long skillId) {
		return Optional.ofNullable(skillRepository.findById(skillId).get())
				.orElseThrow(() -> new ResourceNotFoundException("Skill Id " + skillId + " not found"));
	}

	@HystrixCommand(fallbackMethod = "fallback_findByName", commandKey = "findByName", groupKey = "findByName", ignoreExceptions = {
			ResourceNotFoundException.class })
	public Skill findByName(String skillName) {
		return Optional.ofNullable(skillRepository.findByName(skillName.toLowerCase()))
				.orElseThrow(() -> new ResourceNotFoundException("Skill Name " + skillName + " not found"));
	}

	@HystrixCommand(fallbackMethod = "fallback_findByLikeName", commandKey = "findByLikeName", groupKey = "findByLikeName")
	public List<Skill> findByLikeName(String skillName) {
		return skillRepository.findByLikeName(skillName.toLowerCase());
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_addSkill", commandKey = "addSkill", groupKey = "addSkill", ignoreExceptions = {
			ResourceExistException.class })
	public Skill addSkill(Skill skill) {

		if (skillRepository.findByName(skill.getName()) != null)
			throw new ResourceExistException("Skill Name " + skill.getName() + " already Exists");

		skillRepository.save(skill);
		return skill;
	}

	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_updateSkill", commandKey = "updateSkill", groupKey = "updateSkill", ignoreExceptions = {
			ResourceNotFoundException.class })
	public Skill updateSkill(Long skillId, Skill skill) {

		return skillRepository.findById(skillId).map(oldSkill -> {
			oldSkill.setName(skill.getName());
			oldSkill.setToc(skill.getToc());
			oldSkill.setPrerequisites(skill.getPrerequisites());
			return skillRepository.save(oldSkill);
		}).orElseThrow(() -> new ResourceNotFoundException("Skill Id " + skillId + " not found"));
	}

	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_deleteSkills", commandKey = "deleteSkills", groupKey = "deleteSkills")
	public void deleteSkills(Long skillId) {

		skillRepository.deleteById(skillId);
	}

	
	// list of fallback method for @HystrixCommand
	public Page<Skill> fallback_findAllSkills(String orderBy, String direction, int page, int size) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Skill fallback_findById(Long skillId) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Skill fallback_findByName(String skillName) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public List<Skill> fallback_findByLikeName(String skillName) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Skill fallback_addSkill(Skill skill) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Skill fallback_updateSkill(Long skillId, Skill skill) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public void fallback_deleteSkills(Long skillId) {
		throw new ServiceUnavailableException("Service Unavailable");
	}
}
