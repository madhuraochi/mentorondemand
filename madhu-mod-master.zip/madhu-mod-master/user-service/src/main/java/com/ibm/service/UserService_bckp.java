//package com.ibm.service;
//
//import java.util.Optional;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
//import org.springframework.data.domain.Sort.Direction;
////import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
////import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Propagation;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.ibm.entity.Role;
//import com.ibm.entity.User;
//import com.ibm.exception.ResourceExistException;
//import com.ibm.exception.ResourceNotFoundException;
//import com.ibm.model.Constants.UserRole;
//import com.ibm.repository.RoleRepository;
//import com.ibm.repository.UserRepository;
//
//
//@Service(value = "userService")
//@Transactional(readOnly = true)
//public class UserService_bckp{
//
//	@Autowired
//	private UserRepository userRepository;
//	
//	@Autowired
//	private RoleRepository roleRepository;
//	
//	@Transactional(propagation = Propagation.REQUIRED)
//	public User signup(User user) {
//
//		if (userRepository.findByName(user.getUserName()) != null)
//			throw new ResourceExistException("User Name " + user.getUserName() + " already Exists");
//
////		PasswordEncoder pencoder = new BCryptPasswordEncoder(4);
////		user.setPassword(pencoder.encode(user.getPassword()));
//		
//		Role role=roleRepository.findByName("ROLE_USER");
//		user.setRole(role);
//		userRepository.save(user);
//		return user;
//	}
//
//	@Transactional(propagation = Propagation.REQUIRED)
//	public User updateProfile(Long userId, User user) {
//
//		return userRepository.findById(userId).map(oldUser -> {
//			// block or unblock user
//			if (!user.getActive().equals(oldUser.getActive()))
//				oldUser.setActive(user.getActive());
//			else {
//			//	PasswordEncoder pencoder = new BCryptPasswordEncoder(4);
//			//	oldUser.setPassword(pencoder.encode(user.getPassword()));
//				oldUser.setPassword(user.getPassword());
//				oldUser.setFirstName(user.getFirstName());
//				oldUser.setLastName(user.getLastName());
//				oldUser.setContactNumber(user.getContactNumber());
//			}
//			return userRepository.save(oldUser);
//		}).orElseThrow(() -> new ResourceNotFoundException("UserId " + userId + " not found"));
//	}
//
//	@Transactional(propagation = Propagation.REQUIRED)
//	public void deleteProfile(Long userId) {
//
//		userRepository.findById(userId).map(user -> {
//			userRepository.delete(user);
//			return true;
//		}).orElseThrow(() -> new ResourceNotFoundException("UserId " + userId + " not found"));
//	}
//
//	@SuppressWarnings("deprecation")
//	public Page<User> findAllUsers(String orderBy, String direction, int page, int size) {
//		Sort sort = null;
//
//		if (direction.equals("ASC")) {
//			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
//		} else if (direction.equals("DESC")) {
//			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
//		}
//		Pageable pageable = new PageRequest(page, size, sort);
//		return userRepository.findAll(pageable);
//	}
//
//	public User findById(Long userId) {
//		return Optional.ofNullable(userRepository.findById(userId).get())
//				.orElseThrow(() -> new ResourceNotFoundException("UserId " + userId + " not found"));
//	}
//
//	public User findByName(String userName) {
//		return Optional.ofNullable(userRepository.findByName(userName))
//				.orElseThrow(() -> new ResourceNotFoundException("User Name " + userName + " not found"));
//	}
//
//}
