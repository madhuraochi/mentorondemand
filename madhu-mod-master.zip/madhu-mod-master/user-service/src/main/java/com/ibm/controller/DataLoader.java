//package com.ibm.controller;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.ApplicationArguments;
//import org.springframework.boot.ApplicationRunner;
//import org.springframework.stereotype.Component;
//
//import com.ibm.entity.User;
//import com.ibm.repository.UserRepository;
//
//
//
//@Component
//public class DataLoader implements ApplicationRunner {
//
//	private static Logger logger = LoggerFactory.getLogger(DataLoader.class);
//
//	@Autowired
//	private UserRepository userRepository;
//
//	
//
//	@Override
//	public void run(ApplicationArguments applicationArguments) throws Exception {
//
//		if (userRepository.findByName("admin") == null) {
//			User user = new User();
//			user.setUserName("admin");
//			user.setPassword("$2a$04$j5Px7Uk5a/sgJcHMlBkGk.GH0tFSrPpfn5VqA5MByr8vBWdN4qU3a");
//			user.setFirstName("Admin");
//			user.setLastName("Admin");
//			user.setContactNumber(9434580584L);
//			user.setRole("ADMIN");
//			user.setActive(true);
//			user.setConfirmedSignUp(true);
//		//	user.setPersistent(true); // to create created_date
//			userRepository.save(user);
//			logger.info("admin user inserted");
//		} else
//			logger.warn("admin user already exist");
//	}
//}
