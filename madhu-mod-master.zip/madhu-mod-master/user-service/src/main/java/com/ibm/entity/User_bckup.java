//package com.ibm.entity;
//
//import java.util.HashSet;
//import java.io.Serializable;
//
//import java.util.Set;
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
//import javax.persistence.OneToOne;
//import javax.persistence.Table;
//import javax.validation.constraints.Email;
//import javax.validation.constraints.Min;
//import javax.validation.constraints.NotBlank;
////import javax.validation.constraints.Email;
////import javax.validation.constraints.NotBlank;
////import javax.validation.constraints.NotNull;
////import javax.validation.constraints.Pattern;
////import javax.validation.constraints.Positive;
////import com.fasterxml.jackson.annotation.JsonManagedReference;
//import javax.validation.constraints.NotNull;
//import javax.validation.constraints.Pattern;
//
//import com.fasterxml.jackson.annotation.JsonBackReference;
//
//@Entity
//@Table(name = "user")
//public class User_bckup extends AuditModel {
//
//	/**
//	 * 
//	 */
//	private static final long serialVersionUID = 1L;
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long id;
//
//	@NotNull(message = "User Name is compulsory")
//	@NotBlank(message = "User Name is compulsory")
//	@Email(message = "User Name should be email id")
//	@Column(name = "user_name", nullable = false)
//	private String userName;
//
//	//@Min(value = 6, message="Password should be 6 character long")
//	@Column(name = "password", nullable = false)
//	private String password;
//
//	@NotNull(message = "First Name is compulsory")
//	@NotBlank(message = "First Name is compulsory")
//	@Pattern(regexp = "[a-z-A-Z]*", message = "First Name has invalid characters")
//	@Column(name = "first_name", nullable = false)
//	private String firstName;
//
//	@NotNull(message = "Last Name is compulsory")
//	@NotBlank(message = "Last Name is compulsory")
//	@Pattern(regexp = "[a-z-A-Z]*", message = "Last Name has invalid characters")
//	@Column(name = "last_name", nullable = false)
//	private String lastName;
//
////	@Positive(message = "Contact Number should be positive value")
//	// @Length(min=10, max=10, message="Contact Number should be 10 digit long")
//	@Column(name = "contact_number", nullable = false)
//	private String contactNumber;
//
//	@Column(name = "active", nullable = true)
//	private String active;
//
//	@Column(name = "reg_code", nullable=false)
//	private String regCode;
//	
//	
////	@OneToOne(fetch = FetchType.LAZY, optional = false)
////    @JoinColumn(name = "role_id", nullable = false)
////    private Role role;
//	
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "role_id", nullable = false)
//	@JsonBackReference(value = "role-users")
//	private Role role;
//	
//	public User_bckup() {
//		super();
//	};
//	
//	
//    public User_bckup(String userName, String password, String firstName, String lastName, String contactNumber, String reg_code) {
//    	super();
//    	this.userName = userName;
//    	this.password = password;
//        this.firstName = firstName;
//        this.lastName = lastName;
//        this.contactNumber = contactNumber;
//        this.regCode = reg_code;
//    }
//	
//
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	public String getUserName() {
//		return userName;
//	}
//
//	public void setUserName(String userName) {
//		this.userName = userName;
//	}
//
//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//	public String getFirstName() {
//		return firstName;
//	}
//
//	public void setFirstName(String firstName) {
//		this.firstName = firstName;
//	}
//
//	public String getLastName() {
//		return lastName;
//	}
//
//	public void setLastName(String lastName) {
//		this.lastName = lastName;
//	}
//
//	
//
//	public String getContactNumber() {
//		return contactNumber;
//	}
//
//
//	public void setContactNumber(String contactNumber) {
//		this.contactNumber = contactNumber;
//	}
//
//	public String getActive() {
//		return active;
//	}
//
//
//	public void setActive(String active) {
//		this.active = active;
//	}
//
//
//	public Role getRole() {
//		return role;
//	}
//
//
//	public void setRole(Role role) {
//		this.role = role;
//	}
//
//
//	public String getRegCode() {
//		return regCode;
//	}
//
//
//	public void setRegCode(String regCode) {
//		this.regCode = regCode;
//	}
//
//	
//
//}
