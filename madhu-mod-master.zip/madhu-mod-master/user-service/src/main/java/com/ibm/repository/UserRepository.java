package com.ibm.repository;



import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ibm.entity.User;




@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
	@Query(value = "SELECT u FROM User u WHERE u.userName=?1")
	public User findByName(String userName);
	
	@Query(value = "SELECT u FROM User u")
	Page<User> findAll(Pageable pageable);
	
	@Query(value = "SELECT u FROM User u WHERE u.userName=?1 AND u.confirmedSignUp=true AND u.active=true AND u.resetPassword=false")
	//@Query(value = "SELECT u FROM User u WHERE u.userName=?1")
	public User findByConfirmedUser(String userName);
	
	@Query(value = "SELECT u FROM User u WHERE u.userName=?1 AND u.regCode=?2")
	public User findUserByNameRegCodeForSignUp(String userName, String token);
	
//	@Query(value = "SELECT u FROM User WHERE u.userName=?1 AND u.regCode=?2 AND u.confirmedSignUp=true AND u.resetPasswordDate > 'new Date(ISODate().getTime()-1000*60*15'")
	@Query(value = "SELECT u FROM User u WHERE u.userName=?1 AND u.regCode=?2")
	public User findUserByNameRegCodeForPwdReset(String userName, String token);
	
}
