package com.ibm.security;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import com.ibm.mod.security.JsonWebTokenSecurityConfig;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends JsonWebTokenSecurityConfig {

	@Override
	protected void setupAuthorization(HttpSecurity http) throws Exception {
		http.authorizeRequests()
		.antMatchers("/v2/api-docs", "/users/swagger-ui.html").permitAll()
		.antMatchers("/actuator/**", "/hystrix", "/hystrix/**", "/favicon.ico", "/webjars/**", "/proxy.stream**").permitAll()
		.antMatchers("/favicon.ico", "/css/**", "/js/**", "/images/**").permitAll()
		.antMatchers("/confirmUser", "/users/confirmUser", "/resetPassword", "/users/resetPassword").permitAll()
		.antMatchers("/users/signin", "/users/signup").permitAll()
		.antMatchers("/users/findById/**", "/users/findByName/**", "/users/forgetPassword/**").permitAll()
		.anyRequest().authenticated();
	}

}
