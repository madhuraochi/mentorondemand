//package com.ibm.controller;
//
//import java.util.ArrayList;
//import java.util.List;
//
//
//import javax.validation.Valid;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Page;
//
//import org.springframework.http.ResponseEntity;
////import org.springframework.security.access.prepost.PreAuthorize;
////import org.springframework.security.authentication.AuthenticationManager;
////import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
////import org.springframework.security.core.Authentication;
////import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.ibm.entity.User;
//import com.ibm.exception.PaginationSortingException;
//import com.ibm.pagination.Direction;
//import com.ibm.pagination.OrderBy;
//import com.ibm.service.UserService;
//
//
//@RestController
////@CrossOrigin(origins = "*")
//@RequestMapping("/users")
//public class UserController_bckp {
//
////	@Autowired
////	private AuthenticationManager authenticationManager;
////
////	@Autowired
////	private TokenProvider jwtTokenUtil;
//
//	@Autowired
//	private UserService userService;
//
//
//
////	@PostMapping("/signin")
////	public ResponseEntity<?> signin(@RequestBody User loginUser) {
////
////		final Authentication authentication = authenticationManager.authenticate(
////                new UsernamePasswordAuthenticationToken(
////                        loginUser.getUserName(),
////                        loginUser.getPassword()
////                )
////        );
////        SecurityContextHolder.getContext().setAuthentication(authentication);
////        final String token = jwtTokenUtil.generateToken(authentication);
////        return ResponseEntity.ok(new AuthToken(token, loginUser.getUserName(), UserRole.ROLE_USER.getRole()));
////	}
//
//	@PostMapping("/signup")
//	public ResponseEntity<?> signup(@RequestBody User user) {
//		//@Valid
//		System.out.println("Received user from request "+user.getUserName());
//
//		userService.signup(user);
//		return ResponseEntity.ok("Signup successfully");
//	}
//
////	@PreAuthorize("hasRole('USER')")
//	@PutMapping("/updateProfile/{userId}")
//	public ResponseEntity<?> updateProfile(@PathVariable(value = "userId", required = true) Long userId,
//			@Valid @RequestBody User user) {
//
//		userService.updateProfile(userId, user);
//		return ResponseEntity.ok("Profile updated successfully");
//	}
//
////	@PreAuthorize("hasRole('ADMIN')")
//	@DeleteMapping("/deleteProfile/{userId}")
//	public ResponseEntity<?> deleteProfile(@PathVariable(value = "userId", required = true) Long userId) {
//
//		userService.deleteProfile(userId);
//		return ResponseEntity.ok("Profile deleted successfully");
//	}
//	
////	@PreAuthorize("hasRole('ADMIN')")
//	@GetMapping("/findAllUsers")
//	public Page<User> findAllUsers(@RequestParam(value = "orderBy", required = true) String orderBy,
//			@RequestParam(value = "direction", required = true) String direction,
//			@RequestParam(value = "page", required = true) int page,
//			@RequestParam(value = "size", required = true) int size) {
//
//		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
//				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
//			throw new PaginationSortingException("Invalid sort direction");
//		}
//		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.USERID.getOrderByCode()))) {
//			throw new PaginationSortingException("Invalid orderBy condition");
//		}
//
//		return userService.findAllUsers(orderBy, direction, page, size);
//	}
//
////	@PreAuthorize("hasAnyRole('USER', 'ADMIN')")
//	@GetMapping("/viewProfile/{userId}")
//	public User viewProfile(@PathVariable(value = "userId", required = true) Long userId) {
//
//		return userService.findById(userId);
//	}
//
////	@PreAuthorize("hasAnyRole('USER', 'ADMIN')")
//	@GetMapping("/viewProfile/{userName}")
//	public User viewProfile(@PathVariable(value = "userName", required = true) String userName) {
//		return userService.findByName(userName);
//	}
////
////	@PreAuthorize("hasRole('USER')")
////	@GetMapping("/findMentorByTechnology/{skillName}/{startDate}/{endDate}/{startTime}/{endTime}")
////	public Page<SkillDtls> findMentorByTechnology(@PathVariable(value = "skillName", required = true) String skillName,
////			@PathVariable(value = "startDate", required = true) String startDate,
////			@PathVariable(value = "endDate", required = true) String endDate,
////			@PathVariable(value = "startTime", required = true) String startTime,
////			@PathVariable(value = "endTime", required = true) String endTime,
////			@RequestParam(value = "orderBy", required = true) String orderBy,
////			@RequestParam(value = "direction", required = true) String direction,
////			@RequestParam(value = "page", required = true) int page,
////			@RequestParam(value = "size", required = true) int size) {
////
////		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
////				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
////			throw new PaginationSortingException("Invalid sort direction");
////		}
////		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.USERID.getOrderByCode()))) {
////			throw new PaginationSortingException("Invalid orderBy condition");
////		}
////
////		return mentorService.findMentorByTechnology(skillName.toLowerCase(), startDate, endDate, startTime, endTime,
////				orderBy, direction, page, size);
////
////	}
////
////	@PreAuthorize("hasRole('USER')")
////	@GetMapping("/findTrainingsByUserIdAndStatus/{userId}/{status}")
////	public Page<Trainings> findTrainingsByUserIdAndStatus(@PathVariable(value = "userId", required = true) Long userId,
////			@PathVariable(value = "status", required = true) String status,
////			@RequestParam(value = "orderBy", required = true) String orderBy,
////			@RequestParam(value = "direction", required = true) String direction,
////			@RequestParam(value = "page", required = true) int page,
////			@RequestParam(value = "size", required = true) int size) {
////
////		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
////				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
////			throw new PaginationSortingException("Invalid sort direction");
////		}
////		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.USERID.getOrderByCode()))) {
////			throw new PaginationSortingException("Invalid orderBy condition");
////		}
////
////		List<String> trainingStatus = new ArrayList<String>();
////		if (status.equals(TrainingStatus.INPROGRESS.getStatus())) {
////			for (String str : Constants.getInProgress())
////				trainingStatus.add(str);
////		} else if (status.equals(TrainingStatus.COMPLETED.getStatus()))
////			trainingStatus.add(TrainingStatus.COMPLETED.getStatus());
////		else
////			trainingStatus.add(status);
////
////		return trainingService.findTrainingsByUserIdAndStatus(userId, trainingStatus, orderBy, direction, page, size);
////	}
////
////	@PreAuthorize("hasRole('USER')")
////	@GetMapping("/findTrainingsByMentorId/{userId}/{mentorId}/{skillId}")
////	public Page<Trainings> findTrainingsByMentorId(@PathVariable(value = "userId", required = true) Long userId,
////			@PathVariable(value = "mentorId", required = true) Long mentorId,
////			@PathVariable(value = "skillId", required = true) Long skillId,
////			@RequestParam(value = "orderBy", required = true) String orderBy,
////			@RequestParam(value = "direction", required = true) String direction,
////			@RequestParam(value = "page", required = true) int page,
////			@RequestParam(value = "size", required = true) int size) {
////
////		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
////				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
////			throw new PaginationSortingException("Invalid sort direction");
////		}
////		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.USERID.getOrderByCode()))) {
////			throw new PaginationSortingException("Invalid orderBy condition");
////		}
////
////		return trainingService.findTrainingsByMentorId(userId, mentorId, skillId, orderBy, direction, page, size);
////	}
////
////	// send Proposal
////	@PreAuthorize("hasRole('USER')")
////	@PostMapping("/addProposal/{userId}/{mentorId}/{skillId}")
////	public ResponseEntity<?> addProposal(@PathVariable(value = "userId", required = true) Long userId,
////			@PathVariable(value = "mentorId", required = true) Long mentorId,
////			@PathVariable(value = "skillId", required = true) Long skillId, @Valid @RequestBody Trainings training) {
////
////		trainingService.addTraining(userId, mentorId, skillId, training);
////		return ResponseEntity.ok("Proposal added successfully");
////	}
////
////	@PreAuthorize("hasRole('USER')")
////	@PutMapping("/updateTraining/{userId}/{mentorId}/{skillId}/{trainingId}")
////	public ResponseEntity<?> updateTraining(@PathVariable(value = "userId", required = true) Long userId,
////			@PathVariable(value = "mentorId", required = true) Long mentorId,
////			@PathVariable(value = "skillId", required = true) Long skillId,
////			@PathVariable(value = "trainingId", required = true) Long trainingId,
////			@Valid @RequestBody Trainings training) {
////
////		System.out.println("userId " + userId);
////		System.out.println("mentorId " + mentorId);
////		System.out.println("skillId " + skillId);
////		System.out.println("trainingId " + trainingId);
////		trainingService.updateTraining(userId, mentorId, skillId, trainingId, training);
////		return ResponseEntity.ok("Training updated successfully");
////	}
//
//}