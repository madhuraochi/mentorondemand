package com.ibm.model;

public class Constants_bckp {

	public enum UserRole {

		ROLE_ADMIN("ADMIN"), ROLE_MENTOR("MENTOR"), ROLE_USER("USER");
		private final String role;

		private UserRole(String role) {
			this.role = role;
		}

		public String getRole() {
			return role;
		}
	}
}
