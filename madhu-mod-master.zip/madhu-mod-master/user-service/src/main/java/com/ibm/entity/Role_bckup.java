//package com.ibm.entity;
//
//import java.util.HashSet;
//import java.util.Set;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.OneToMany;
//import javax.persistence.OneToOne;
//import javax.persistence.Table;
//
//import com.fasterxml.jackson.annotation.JsonManagedReference;
//
//@Entity
//@Table(name = "role")
//public class Role_bckup {
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.SEQUENCE)
//	private long id;
//
//	@Column(name = "name", nullable = false)
//	private String name;
//
//	@Column(name = "description", nullable = false)
//	private String description;
//	
////	@OneToOne(fetch = FetchType.LAZY,
////            cascade =  CascadeType.ALL,
////            mappedBy = "role")
////    private User user;
//	
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "role")
//	@JsonManagedReference(value = "role-users")
//	private Set<User> users = new HashSet<>();
//
//	/*@JsonBackReference(value = "admin-role")
//	@OneToOne(fetch = FetchType.LAZY, optional = true)
//	@JoinColumn(name = "admin_id")
//	private Admin admin;
//
//	@JsonBackReference(value = "user-role")
//	@OneToOne(fetch = FetchType.LAZY, optional = true)
//	@JoinColumn(name = "user_id")
//	private User user;
//
//	@JsonBackReference(value = "mentor-role")
//	@OneToOne(fetch = FetchType.LAZY, optional = true)
//	@JoinColumn(name = "mentor_id")
//	private Mentor mentor;*/
//
//	public long getId() {
//		return id;
//	}
//
//	public void setId(long id) {
//		this.id = id;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//	/*public Admin getAdmin() {
//		return admin;
//	}
//
//	public void setAdmin(Admin admin) {
//		this.admin = admin;
//	}
//
//	
//	public Mentor getMentor() {
//		return mentor;
//	}
//
//	public void setMentor(Mentor mentor) {
//		this.mentor = mentor;
//	}*/
//
//	public Role_bckup() {
//		super();
//	}
//
//	public Role_bckup(String name, String description) {
//		super();
//		this.name = name;
//		this.description = description;
//	}
//
//	
//	public Set<User> getUsers() {
//		return users;
//	}
//
//	public void setUsers(Set<User> users) {
//		this.users = users;
//	}
//	
////	public User getUser() {
////		return user;
////	}
////
////	public void setUser(User user) {
////		this.user = user;
////	}
//	
//	
//	
//
//}
