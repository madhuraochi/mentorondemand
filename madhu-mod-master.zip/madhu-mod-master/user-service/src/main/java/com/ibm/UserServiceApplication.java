package com.ibm;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

//import com.ibm.controller.DataLoader;
import com.ibm.entity.User;
import com.ibm.repository.UserRepository;




@EnableHystrixDashboard
@EnableCircuitBreaker
@EnableEurekaClient
@SpringBootApplication
@EnableJpaAuditing
@EnableJpaRepositories
//public class UserServiceApplication{
public class UserServiceApplication implements CommandLineRunner{
	
//private static Logger logger = LoggerFactory.getLogger(DataLoader.class);

@Autowired
private UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(UserServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		if (userRepository.findByName("admin") == null) {
			User user = new User();
			user.setUserName("admin");
			user.setPassword("$2a$04$j5Px7Uk5a/sgJcHMlBkGk.GH0tFSrPpfn5VqA5MByr8vBWdN4qU3a");
			user.setFirstName("Admin");
			user.setLastName("Admin");
			user.setContactNumber(9434580584L);
			user.setRole("ADMIN");
			user.setActive(true);
			user.setConfirmedSignUp(true);
			user.setRegCode("AD12345");
		//	user.setPersistent(true); // to create created_date
			userRepository.save(user);
			System.out.println("admin user inserted");
		} else
			System.out.println("admin user already exist");
		
	}
}

