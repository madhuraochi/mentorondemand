package com.ibm.mod.security;

import static com.ibm.mod.model.Constants.TOKEN_PREFIX;
import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Component;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureException;

@Component
public class JsonWebTokenAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	private TokenProvider jwtTokenUtil;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String authToken = null, username = null;
		UserDetails userDetails = null;
		Authentication auth = null;

		if (authentication.getClass().isAssignableFrom(PreAuthenticatedAuthenticationToken.class)
				&& authentication.getPrincipal() != null) {
			String tokenHeader = (String) authentication.getPrincipal();
			authToken = tokenHeader.replace(TOKEN_PREFIX, "");
			try {
				username = jwtTokenUtil.getUsernameFromToken(authToken);
				Collection<? extends GrantedAuthority> authorities = jwtTokenUtil.getRolesFromToken(authToken);
				if (username != null && authorities != null && !jwtTokenUtil.isTokenExpired(authToken)) {
					userDetails = new User(username, "", authorities);
				}
				if (userDetails != null)
					auth = new JsonWebTokenAuthentication(userDetails, tokenHeader);
			} catch (IllegalArgumentException e) {
				// logger.error("an error occured during getting username from token", e);
			} catch (ExpiredJwtException e) {
				// req.setAttribute("expired", "Token expired and not valid anymore");
				// logger.warn("the token is expired and not valid anymore", e);
			} catch (SignatureException e) {
				// logger.error("Authentication Failed. Username or Password not valid.");
			}
		} else {
			auth = authentication;
		}
		return auth;
	}

	// @Override
	public boolean supports(Class<?> authentication) {
		return authentication.isAssignableFrom(PreAuthenticatedAuthenticationToken.class)
				|| authentication.isAssignableFrom(JsonWebTokenAuthentication.class);
	}

}
