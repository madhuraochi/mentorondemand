package com.ibm.mod.job;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.ibm.mod.entity.Payment;
import com.ibm.mod.model.Constants.TrainingStatus;
import com.ibm.mod.model.PendingPaymentDtls;
import com.ibm.mod.service.PaymentService;

@Component
public class ScheduledJobs {

	private static Logger logger = LoggerFactory.getLogger(ScheduledJobs.class);

	@Autowired
	private PaymentService paymentService;
	
	@Scheduled(cron = "${payment.job.cron}")
	public synchronized void addPendingPaymentJob() {

		List<String> trainingStatus = new ArrayList<String>();
		trainingStatus.add(TrainingStatus.TRAINING_STARTED.getStatus());
		trainingStatus.add(TrainingStatus.NOT_COMPLETED.getStatus());
		trainingStatus.add(TrainingStatus.COMPLETED.getStatus());
		Payment payment = null;
		Float amountToMentor = 0.0f;

		List<PendingPaymentDtls> pendingPaymentDtlsList = paymentService.findPendingPayment(trainingStatus);
		logger.info("Number of records found " + pendingPaymentDtlsList.size());
		for (PendingPaymentDtls pp : pendingPaymentDtlsList) {
			payment = new Payment();
			float progress = Float.parseFloat(pp.getProgress().replaceAll("%", ""));
			amountToMentor = ((pp.getAmountReceived() - pp.getCommissionAmount()) * ((float) progress / 100))
					- pp.getTotalAmountToMentor();
			payment.setAmountToMentor(amountToMentor);
			payment.setRemarks("Amount " + amountToMentor + " paid to mentor");
			paymentService.addPayment(pp.getMentorId(), pp.getTrainingId(), payment);
		}
	}

}
