package com.ibm.mod.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import java.util.List;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.ibm.mod.model.TrainingDtls;

@FeignClient(name = "training-service")
@RibbonClient(name = "training-service")
public interface TrainingServiceProxy {

	@GetMapping("/trainings/findById/{trainingId}")
	public TrainingDtls findById(
			@RequestHeader("Authorization") String authToken,
			@PathVariable(value = "skillId", required = true) Long skillId);

	// GET http://localhost:8080/trainings/findByTrainingStatus/1,2,3,4
	@GetMapping("/trainings/findByTrainingStatus/{trainingStatus}")
	public List<TrainingDtls> findByTrainingStatus(
			@PathVariable(value = "trainingStatus", required = true) List<String> trainingStatus);
}