package com.ibm.mod.proxy;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import feign.auth.BasicAuthRequestInterceptor;

@Configuration
public class FeignClientConfiguration {

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor("admin", "$2a$04$szK2yjKu69Z1h5Lss1Sbe.bIFZd3Z/xzC5/uVX3SYWl.YGXd5y6k.");
    }
}
