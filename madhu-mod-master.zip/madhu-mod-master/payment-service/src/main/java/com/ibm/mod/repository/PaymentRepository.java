package com.ibm.mod.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.ibm.mod.entity.Payment;
import com.ibm.mod.model.PaymentDtls;
//import com.ibm.mod.model.PendingPaymentDtls;


//public interface PaymentRepository extends PagingAndSortingRepository<Payment, Long> {
public interface PaymentRepository extends JpaRepository<Payment, Long> {
	

	String findPaymentDtlsByMentorid = "SELECT p FROM Payment p WHERE p.mentorId=?1 AND p.createdDate BETWEEN ?2 AND ?3" ; 
	@Query(value = findPaymentDtlsByMentorid)
	Page<Payment> findPaymentDtlsByMentorid(Long mentorId,Date startDate, Date endDate, Pageable pageable);

	
	String findPaymentDtlsByDateRange = "SELECT p FROM Payment p WHERE p.createdDate BETWEEN ?2 AND ?3";
	@Query(value = findPaymentDtlsByDateRange)
	Page<Payment> findPaymentDtlsByDateRange(Date startDate, Date endDate, Pageable pageable);
	
	@Query("SELECT SUM(amount) from Payment WHERE mentorId=?1 AND trainingId=?2")
	public PaymentDtls aggregateByMentorId(Long mentorId, Long trainingId);
	
}
