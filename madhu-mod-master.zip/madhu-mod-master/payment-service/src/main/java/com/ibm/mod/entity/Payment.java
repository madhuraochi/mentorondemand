package com.ibm.mod.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "payment")
public class Payment extends AuditModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "mentor_id", nullable = true)
	private Long mentorId;
	
	@Column(name = "training_id", nullable = true)
	private Long trainingId;

	@Column(name = "txn_type", nullable = true)
	private String txnType= "CR"; //dr or cr

	@Column(name = "txn_status", nullable = true)
	private String txnStatus;

	@Column(name = "amount_to_mentor", nullable = false)
	private Float amount;

	@Column(name = "remarks", nullable = false)
	private String remarks;
	
	
	public Payment() {
		super();
	};
	
	public Payment(Long mentorId, Long trainingId, String txnType, Date txnDate, String txnStatus, Float amountToMentor, String remarks) {
		super();
		this.mentorId = mentorId;
		this.trainingId = trainingId;
		this.txnType = txnType;
		this.txnStatus = txnStatus;
		this.amount = amountToMentor;
		this.remarks = remarks;
		
	};

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMentorId() {
		return mentorId;
	}

	public void setMentorId(Long mentorId) {
		this.mentorId = mentorId;
	}

	public Long getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(Long trainingId) {
		this.trainingId = trainingId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}


	public String getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
