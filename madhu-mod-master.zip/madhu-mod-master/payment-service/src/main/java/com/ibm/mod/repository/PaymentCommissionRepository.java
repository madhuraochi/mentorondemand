package com.ibm.mod.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.ibm.mod.entity.Payment;
import com.ibm.mod.entity.PaymentCommission;

public interface PaymentCommissionRepository extends JpaRepository<PaymentCommission, Long>
 {

}
