package com.ibm.mod.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.ibm.mod.model.UserDtls;

@FeignClient(name = "user-service")
@RibbonClient(name = "user-service")
public interface UserServiceProxy {

	@GetMapping("/users/findById/{userId}")
	public UserDtls findById(
			@PathVariable(value = "userId", required = true) Long userId);

}