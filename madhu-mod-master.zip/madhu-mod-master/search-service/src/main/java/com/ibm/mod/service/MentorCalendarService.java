package com.ibm.mod.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.ibm.mod.entity.MentorCalendar;
import com.ibm.mod.exception.ResourceExistException;
import com.ibm.mod.exception.ResourceNotFoundException;
import com.ibm.mod.exception.ServiceUnavailableException;
import com.ibm.mod.model.MentorCalendarDtls;
import com.ibm.mod.model.SkillDtls;
import com.ibm.mod.model.UserDtls;
import com.ibm.mod.proxy.SkillServiceProxy;
import com.ibm.mod.proxy.UserServiceProxy;
import com.ibm.mod.reprository.MentorCalendarRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
@Transactional(readOnly = true)
public class MentorCalendarService {

	@Autowired
	private MentorCalendarRepository mentorCalendarRepository;

	@Autowired
	private SkillServiceProxy skillProxy;

	@Autowired
	private UserServiceProxy userProxy;
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_addCalendarEntry", commandKey = "addCalendarEntry", groupKey = "addCalendarEntry", ignoreExceptions = {
			ResourceNotFoundException.class, ResourceExistException.class })
	public MentorCalendar addCalendarEntry(Long userId, Long skillId, String startDateStr, String endDateStr,
			String startTimeStr, String endTimeStr) {

		UserDtls mentor = userProxy.findById(userId);
		SkillDtls skill = skillProxy.findById(skillId);

		if (mentor == null)
			throw new ResourceNotFoundException("Mentor Id " + userId + " not found");

		if (skill == null)
			throw new ResourceNotFoundException("Skill Id " + skill + " not found");

		List<MentorCalendar> calendarEntries = mentorCalendarRepository.findCalendarEntry(userId, startDateStr,
				endDateStr, startTimeStr, endTimeStr);
		if (calendarEntries.size() > 0)
			throw new ResourceExistException("Calendar entry for Mentor Id " + userId + " already entered for the period " + startDateStr
							+ " - " + endDateStr + " and " + startTimeStr + " - " + endTimeStr);

		MentorCalendar mentorCalendar = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate startDate = LocalDate.parse(startDateStr, formatter);
		LocalDate endDate = LocalDate.parse(endDateStr, formatter).plusDays(1);
		for (LocalDate date = startDate; date.isBefore(endDate); date = date.plusDays(1)) {
			mentorCalendar = new MentorCalendar();
			mentorCalendar.setStartDate(date.toString());
			mentorCalendar.setEndDate(date.toString());
			mentorCalendar.setStartTime(startTimeStr);
			mentorCalendar.setEndTime(endTimeStr);
			mentorCalendar.setMentorId(mentor.getId());
			mentorCalendar.setSkillId(skillId);
			mentorCalendarRepository.save(mentorCalendar);
		}

		return mentorCalendar;

	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_findMentorCalendarByMentorId", commandKey = "findMentorCalendarByMentorId", groupKey = "findMentorCalendarByMentorId")
	public List<MentorCalendarDtls> findMentorCalendarByMentorId(Long mentorId, String startDate, String endDate) {
		/*if (startDate == null || endDate == null) {
			LocalDate today = LocalDate.now();
			startDate = today.withDayOfMonth(1).toString();
			endDate = today.withDayOfMonth(today.lengthOfMonth()).toString();
		}*/
		
		List<MentorCalendarDtls> mentorCalendarDtlsList = new ArrayList<>();
		MentorCalendar mentorCalendarObj = null;
		MentorCalendarDtls mentorCalendarDtlObj = null;
		SkillDtls skill = null;
		List<MentorCalendar> mentorCalendarList = mentorCalendarRepository.findMentorCalendarByMentorId(mentorId, startDate, endDate);
		for (int index = 0; index < mentorCalendarList.size(); index++) {
			mentorCalendarObj = mentorCalendarList.get(index);
			skill = skillProxy.findById(mentorCalendarObj.getSkillId());
			if (skill != null) {
				mentorCalendarDtlObj = new MentorCalendarDtls();
				BeanUtils.copyProperties(mentorCalendarObj, mentorCalendarDtlObj);
				mentorCalendarDtlObj.setSkillName(skill.getName());
				mentorCalendarDtlsList.add(mentorCalendarDtlObj);
			}
		}

		return mentorCalendarDtlsList;
	}

	
	// list of fallback method for @HystrixCommand
	public MentorCalendar fallback_addCalendarEntry(Long userId, Long skillId, String startDateStr, String endDateStr,
			String startTimeStr, String endTimeStr) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public List<MentorCalendarDtls> fallback_findMentorCalendarByMentorId(Long mentorId, String startDate,
			String endDate) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

}
