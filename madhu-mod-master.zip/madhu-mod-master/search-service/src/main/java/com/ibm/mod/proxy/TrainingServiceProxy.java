package com.ibm.mod.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import java.util.List;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ibm.mod.model.TrainingDtls;

@FeignClient(name = "training-service") 
@RibbonClient(name = "training-service")
public interface TrainingServiceProxy {

	@PostMapping("/trainings/findAvgRating")
	public List<TrainingDtls> findAvgRating(
			@RequestBody List<TrainingDtls> list);

}