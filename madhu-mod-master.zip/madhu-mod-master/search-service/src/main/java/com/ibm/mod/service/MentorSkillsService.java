package com.ibm.mod.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.ibm.mod.entity.MentorSkills;
import com.ibm.mod.exception.ResourceExistException;
import com.ibm.mod.exception.ResourceNotFoundException;
import com.ibm.mod.exception.ServiceUnavailableException;
import com.ibm.mod.model.MentorSkillsDtls;
import com.ibm.mod.model.SkillDtls;
import com.ibm.mod.model.TrainingDtls;
import com.ibm.mod.model.UserDtls;
import com.ibm.mod.proxy.SkillServiceProxy;
import com.ibm.mod.proxy.TrainingServiceProxy;
import com.ibm.mod.proxy.UserServiceProxy;
import com.ibm.mod.reprository.MentorSkillsRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
@Transactional(readOnly = true)
public class MentorSkillsService {

	@Autowired
	private MentorSkillsRepository mentorSkillsRepository;

	@Autowired
	private SkillServiceProxy skillProxy;

	@Autowired
	private UserServiceProxy userProxy;
	
	@Autowired
	private TrainingServiceProxy trainingProxy;
	
	@SuppressWarnings("deprecation")
	@HystrixCommand(fallbackMethod = "fallback_findBySkillIdDateRange", commandKey = "findBySkillIdDateRange", groupKey = "findBySkillIdDateRange")
	public Page<MentorSkillsDtls> findBySkillIdDateRange(Long skillId, String startDate, String endDate,
			String startTime, String endTime, String orderBy, String direction, int page, int size) {

		List<TrainingDtls> trainingDtlsList = new ArrayList<>();
		List<TrainingDtls> avgRatingList = new ArrayList<>();
		List<MentorSkillsDtls> mentorSkillDtlsList = new ArrayList<>();
		MentorSkillsDtls mentorSkillDtlsObj = null;
		UserDtls mentor = null;
		Sort sort = null;
		if (direction.equals("ASC")) {
			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
		} else if (direction.equals("DESC")) {
			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
		}
		Pageable pageable = new PageRequest(page, size, sort);
		
		List<MentorSkills> mentorSkillList = mentorSkillsRepository.findBySkillIdDateRange(skillId, startDate, endDate, startTime, endTime, pageable).getContent();
		if(mentorSkillList.size() > 0) {
			for (MentorSkills mentorSkillObj : mentorSkillList)
			    trainingDtlsList.add(new TrainingDtls(mentorSkillObj.getMentorId(), skillId)); 
			avgRatingList = trainingProxy.findAvgRating(trainingDtlsList);
		}
		System.out.println("avgRatingList "+avgRatingList);
		for (MentorSkills mentorSkillObj : mentorSkillList) {
			mentor = userProxy.findById(mentorSkillObj.getMentorId());
			if (mentor.getActive().booleanValue()) {				
				mentorSkillDtlsObj = new MentorSkillsDtls();
				BeanUtils.copyProperties(mentorSkillObj, mentorSkillDtlsObj);
				mentorSkillDtlsObj.setMentorName(mentor.getFirstName() + " " + mentor.getLastName());
				int index = avgRatingList.indexOf(new TrainingDtls(mentorSkillObj.getMentorId(), skillId));
				if(index != -1)
				   mentorSkillDtlsObj.setAvgRating(trainingDtlsList.get(index).getAvgRating());
				float totalFees = mentorSkillDtlsObj.getFees() + mentorSkillDtlsObj.getFees()
						* ((mentorSkillDtlsObj.getYearsOfExperience() / 100) + mentorSkillDtlsObj.getAvgRating() / 5);
				mentorSkillDtlsObj.setFees(totalFees);
				mentorSkillDtlsList.add(mentorSkillDtlsObj);
			}
		}
		return new PageImpl<>(mentorSkillDtlsList, pageable, mentorSkillDtlsList.size());
	}
	
	@SuppressWarnings("deprecation")
	@HystrixCommand(fallbackMethod = "fallback_findByMentorId", commandKey = "findByMentorId", groupKey = "findByMentorId")
	public Page<MentorSkillsDtls> findByMentorId(Long mentorId, String orderBy, String direction, int page,
			int size) {
		
		List<MentorSkillsDtls> mentorSkillsDtlsList = new ArrayList<>();
		MentorSkillsDtls mentorSkillDtlObj = null;
		SkillDtls skill = null;
		Sort sort = null;
		if (direction.equals("ASC")) {
			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
		} else if (direction.equals("DESC")) {
			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
		}
		Pageable pageable = new PageRequest(page, size, sort);
		
		List<MentorSkills> mentorSkillsList =  mentorSkillsRepository.findByMentorId(mentorId, pageable).getContent();
		for (MentorSkills mentorSkillObj : mentorSkillsList) {
			skill = skillProxy.findById(mentorSkillObj.getSkillId());
			if (skill != null) {
				mentorSkillDtlObj = new MentorSkillsDtls();
				BeanUtils.copyProperties(mentorSkillObj, mentorSkillDtlObj);
				mentorSkillDtlObj.setSkillName(skill.getName());
				mentorSkillsDtlsList.add(mentorSkillDtlObj);
			}
		}
		return new PageImpl<>(mentorSkillsDtlsList, pageable, mentorSkillsDtlsList.size());
	}
	
	@HystrixCommand(fallbackMethod = "fallback_findByMentorIdSkillId", commandKey = "findByMentorIdSkillId", groupKey = "findByMentorIdSkillId")
	public MentorSkills findByMentorIdSkillId(Long mentorId, Long skillId) {

		return mentorSkillsRepository.findByMentorIdSkillId(mentorId, skillId);

	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_addMentorSkill", commandKey = "addMentorSkill", groupKey = "addMentorSkill", ignoreExceptions = { ResourceNotFoundException.class,
			ResourceExistException.class })
	public MentorSkills addMentorSkill(MentorSkills mentorSkill) {

		UserDtls mentor = userProxy.findById(mentorSkill.getMentorId());
		SkillDtls skill = skillProxy.findById(mentorSkill.getSkillId());
		if (mentor == null)
			throw new ResourceNotFoundException("Mentor Id  " + mentorSkill.getMentorId() + " not found");
		else if (skill == null)
			throw new ResourceNotFoundException("Skill Id  " + mentorSkill.getSkillId() + " not found");

		if (mentorSkillsRepository.findByMentorIdSkillId(mentorSkill.getMentorId(), mentorSkill.getSkillId()) != null)
			throw new ResourceExistException("Mentor already added the Skill");
		mentorSkillsRepository.save(mentorSkill);
		return mentorSkill;
		
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_updateMentorSkill", commandKey = "updateMentorSkill", groupKey = "updateMentorSkill", ignoreExceptions = {
			ResourceNotFoundException.class })
	public MentorSkills updateMentorSkill(Long id, MentorSkills mentorSkill) {

		return mentorSkillsRepository.findById(id).map(oldMentorSkill -> {
			if (mentorSkill.getSelfRating().floatValue() != 0.0f)
				oldMentorSkill.setSelfRating(mentorSkill.getSelfRating());
			if (mentorSkill.getYearsOfExperience().floatValue() != 0.0f)
				oldMentorSkill.setYearsOfExperience(mentorSkill.getYearsOfExperience());
			if (mentorSkill.getTariningsDelivered().intValue() != 0)
				oldMentorSkill.setTariningsDelivered(mentorSkill.getTariningsDelivered());
			if (mentorSkill.getFacilitiesOffered() != null && mentorSkill.getFacilitiesOffered().trim().length() > 0)
				oldMentorSkill.setFacilitiesOffered(mentorSkill.getFacilitiesOffered());
			return mentorSkillsRepository.save(mentorSkill);
		}).orElseThrow(() -> new ResourceNotFoundException("Mentor Skill Id " + id + " not found"));

	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_updateMentorTrainingCount", commandKey = "updateMentorTrainingCount", groupKey = "updateMentorTrainingCount")
	public void updateMentorTrainingCount(Long mentorId, Long skillId) {

		MentorSkills mentorSkillsObj = mentorSkillsRepository.findByMentorIdSkillId(mentorId, skillId);
		if (mentorSkillsObj != null) {
			mentorSkillsObj.setTariningsDelivered(mentorSkillsObj.getTariningsDelivered() + 1);
			mentorSkillsRepository.save(mentorSkillsObj);
		}		
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_deleteMentorSkill", commandKey = "deleteMentorSkill", groupKey = "deleteMentorSkill", ignoreExceptions = {
			ResourceNotFoundException.class })
	public void deleteMentorSkill(Long id) {

		mentorSkillsRepository.findById(id).map(mentorSkill -> {
			mentorSkillsRepository.delete(mentorSkill);
			return true;
		}).orElseThrow(() -> new ResourceNotFoundException("Mentor Skill Id " + id + " not found"));
	}


	public Page<MentorSkillsDtls> fallback_findBySkillIdDateRange(Long skillId, String startDate, String endDate,
			String startTime, String endTime, String orderBy, String direction, int page, int size) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Page<MentorSkillsDtls> fallback_findByMentorId(Long mentorId, String orderBy, String direction, int page,
			int size) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public MentorSkills fallback_findByMentorIdSkillId(Long mentorId, Long skillId) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public MentorSkills fallback_addMentorSkill(MentorSkills mentorSkill) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public MentorSkills fallback_updateMentorSkill(Long id, MentorSkills mentorSkill) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public void fallback_updateMentorTrainingCount(Long mentorId, Long skillId) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public void fallback_deleteMentorSkill(Long id) {
		throw new ServiceUnavailableException("Service Unavailable");
	}
	
}
