package com.ibm.mod.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ibm.mod.exception.ResourceNotFoundException;
import com.ibm.mod.model.SkillDtls;

@FeignClient(name = "technology-service")
@RibbonClient(name = "technology-service")
public interface SkillServiceProxy {

	@GetMapping("/skills/findById/{skillId}")
	public SkillDtls findById(
			@PathVariable(value = "skillId", required = true) Long skillId) throws ResourceNotFoundException;

}