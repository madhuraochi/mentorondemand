package com.ibm.mod.model;

import java.util.Date;

public interface PaymentDtls {

	public Long getId();

	public Date getCreated_date();

	public Float getAmount_to_mentor();

	public String getRemarks();

	public String getUser_name();

	public String getMentor_name();

	public String getSkill_name();

	public String getTxn_type();

	public Date getTxn_date();

	public String getTxn_status();
}
